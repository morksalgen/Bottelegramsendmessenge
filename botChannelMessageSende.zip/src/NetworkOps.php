<?php
namespace MorksalgenTel\MessageSender;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;


class NetworkOps {

    private $client;
    public function __construct() {
        $this->client = new Client();

    }

    public function sendMessage($chatId, $message) {
        $this->sendHttpRequest($chatId, 'https://api.telegram.org/bot' . Config::$BOT_TOKEN . '/sendMessage', $message);
    }

    public function sendHttpRequest($chatId, $url, $message) {
        $res = $this->client->request('POST', $url, [
                    'form_params' => [
                        'chat_id' => $chatId,
                        'text' => $message,
                    ]
                ]);

        //echo $res->getHeader('content-type');
        //echo $res->getBody();

    }
}
