<?php
namespace MorksalgenTel\MessageSender;

class Config {
    public static $BOT_TOKEN = "479226759:AAFA5QUqpVVwnwad4fObXEKXbuyVeTALFZs";
    public static $CHANNEL_ID_ARR = [
          'CahooShop' => '-1001125195998',
        'CahooPick' => '-1001120930006',
        'CahooHadi' => '-1001127133042',
    ];

}
