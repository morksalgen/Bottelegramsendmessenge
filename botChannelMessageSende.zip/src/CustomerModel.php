<?php
namespace MorksalgenTel\MessageSender;

class CustomerModel {
    public $name;
    public $phoneNumber;
    public $address;
    /** OrderModel object **/
    public $order;

    public function __construct($name, $phoneNumber, $address, OrderModel $order) {
        $this->name = $name;
        $this->phoneNumber = $phoneNumber;
        $this->address = $address;
        $this->order = $order;
    }


}
