<?php
namespace MorksalgenTel\MessageSender;

class OrderItemModel {
    public $title;
    public $quantity;
    public $price;
    public $discount;

    public function __construct($title, $quantity, $price, $discount) {
        $this->title = $title;
        $this->quantity = $quantity;
        $this->price = $price;
        $this->discount = $discount;
    }

    public function toString() {
        
    }
}
