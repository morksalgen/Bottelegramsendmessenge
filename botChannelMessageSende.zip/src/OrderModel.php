<?php
namespace MorksalgenTel\MessageSender;

class OrderModel {
    /** OrderItemModel objects **/
    public $orderItems;
    public $costSum;
    public $shippingType;
    public $shippingPrice;
    public $dispatchTime;
    public function __construct(OrderItemModelArray $orderItems, $costSum, $shippingType, $shippingPrice, $dispatchTime) {
        $this->orderItems = $orderItems;
        $this->costSum = $costSum;
        $this->shippingType = $shippingType;
        $this->shippingPrice = $shippingPrice;
        $this->dispatchTime = $dispatchTime;
    }



}
