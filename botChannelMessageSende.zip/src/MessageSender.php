<?php
namespace MorksalgenTel\MessageSender;

class MessageSender {
    private $nops;
    public function __construct(NetworkOps $nops) {
        $this->nops = $nops;
    }
    public function sendToCahooShop(CustomerModel $customer) {
        $this->sendToChannelById(Config::$CHANNEL_ID_ARR['CahooShop'], $customer);
    }

    public function sendToCahooPick(CustomerModel $customer) {
        $this->sendToChannelById(Config::$CHANNEL_ID_ARR['CahooPick'], $customer);
    }

    public function sendToCahooHadi(CustomerModel $customer) {
        $this->sendToChannelById(Config::$CHANNEL_ID_ARR['CahooHadi'], $customer);
    }

    public function sendToAllChannels(CustomerModel $customer) {
        foreach(Config::$CHANNEL_ID_ARR as $channelId) {
            $this->sendToChannelById($channelId, $customer);
        }
    }

    public function sendToChannelById($channelId, CustomerModel $customer) {
        $this->nops->sendMessage($channelId, MessagePresenter::present($customer));
    }

}
