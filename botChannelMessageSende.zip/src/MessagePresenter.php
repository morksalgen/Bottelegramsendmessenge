<?php
/**
 * Created by PhpStorm.
 * User: MorksalgenTel
 * Date: 10/28/2017
 * Time: 12:25 PM
 */

namespace MorksalgenTel\MessageSender;


class MessagePresenter
{
    public static function present(CustomerModel $customer) {
        $messageArray = array();

        array_push($messageArray, self::presentCustomerInfo($customer));
        array_push($messageArray, self::presentOrderInfo($customer->order));
        array_push($messageArray, self::presentOrderItemInfo($customer->order->orderItems->getIterable()));

        return implode(PHP_EOL . "----" . PHP_EOL, $messageArray);
    }

    private static function presentCustomerInfo($customer) {
        $mName = 'نام: ' . $customer->name;
        $mPhoneNumber = 'شماره تلفن: ' . $customer->phoneNumber;
        $mAddress = 'آدرس:‌ ' . $customer->address;

        return $mName . PHP_EOL. $mPhoneNumber . PHP_EOL . $mAddress;
    }

    private static function presentOrderInfo(OrderModel $order) {
        $costSum = 'مجموع قیمت:‌ ' . $order->costSum;
        $dispatchTime = 'زمان ارسال: ' . $order->dispatchTime;
        $shippingType = 'نوع ارسال: ' . $order->shippingType;
        $shippingPrice = 'هزینه ارسال: ' . $order->shippingPrice;
        return $costSum . PHP_EOL . $dispatchTime . PHP_EOL . $shippingPrice . PHP_EOL . $shippingType;
    }

    private static function presentOrderItemInfo($orderItems) {
        $resultArray = array();
        foreach ($orderItems as $orderItem) {
            $title = 'نام کالا: ' . $orderItem->title;
            $quantity = 'تعداد: ' . $orderItem->quantity;
            $price = 'قیمت: ' . $orderItem->price;
            $discount = 'تخفیف: ' . $orderItem->discount;
            array_push($resultArray, $title . PHP_EOL . $quantity  . PHP_EOL . $price  . PHP_EOL . $discount);
        }

        return implode(PHP_EOL, $resultArray);
    }
}