<?php
namespace MorksalgenTel\MessageSender;
use Illuminate\Support\ServiceProvider;

class MessageSenderServiceProvider extends ServiceProvider {
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = false;

    /**
     * Bootstrap the application events.
     *
     * @return void
     */
    public function boot()
    {
    }
    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        // $this->app['MessageSender'] = $this->app->share(function($app)
        // {
        //     return new MessageSender();
        // });
        // $this->app->booting(function()
        // {
        //     $loader = \Illuminate\Foundation\AliasLoader::getInstance();
        //     $loader->alias('MessageSender', 'MorksalgenTel\MessageSender\MessageSender');
        // });

        // $this->app->bind('MessageSender', function($app) {
        //     return new MorksalgenTel\MessageSender\MessageSender();
        // });
    }
    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }
}
