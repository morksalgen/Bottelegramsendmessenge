<?php
/**
 * Created by PhpStorm.
 * User: MorksalgenTel
 * Date: 10/28/2017
 * Time: 1:43 PM
 */

namespace MorksalgenTel\MessageSender;


class OrderItemModelArray
{
    private $items = array();

    public function __construct() {
    }

    public function addItem(OrderItemModel $orderItem) {
        array_push($this->items, $orderItem);
    }

    public function getIterable() {
        return $this->items;
    }
}